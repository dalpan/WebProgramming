<?
echo "---------------------------<br>";
echo "Nama : Danang Avan Maulana <br>";
echo "Nim : 5180411091 <br>";
echo "---------------------------<br>";
?>
<html>
<br><br>
<p>Menghitung Luas Persegi Panjang</p><br>
<form actiton="" method="post">
<table border=0>
<tr>
    <td>Panjang
    <td>:
    <td><input type="text" name="panjang"><br>
</tr>
<tr>
    <td>Lebar
    <td>:
    <td><input type="text" name="lebar"><br>
</tr>
<tr>
    <td><input type="submit" name="input-data" value=Input>
               
</tr>
</table>
</form>
</html>