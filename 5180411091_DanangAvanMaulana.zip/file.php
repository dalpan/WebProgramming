<?
require("require.php");
dalpan("3000");
echo "<br>";
echo $a;
?>
