<?
$a = "Hallo.. saya Dalpan <br> Saya sedang belajar PHP";
function dalpan ($ganteng){
	echo "I love you $ganteng";
}
?>