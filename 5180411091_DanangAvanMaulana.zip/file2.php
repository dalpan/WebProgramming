<?
include ("include.php");

if(isset($_POST["input-data"]))
{
	$panjang=$_POST["panjang"];
	$lebar=$_POST["lebar"];
	$luas=$panjang*$lebar;

}
echo "<br><br>";
echo "Luas persegi panjang : $luas";


echo "<br>";
?>