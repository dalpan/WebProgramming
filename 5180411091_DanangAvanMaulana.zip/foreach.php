<?
$teman[] = "Hilal";
$teman[] = "Syamsul";
$teman[] = "Nando";
echo "Daftar nama teman saya <br>";
foreach ($teman as $key => $value) {
	echo "Nama : $value <br>";
}
echo "<br>";

$a = pow(2,10);
$b = sqrt(100);
$c = ceil(4.25);
$d = floor(4.25);

$hasil=$a * $b;

echo "2 pangkat 10 = $a <br>";
echo "akar 100 = $b <br>";
echo "ceil(4.25) = $c <br>";
echo "floor(4.25) = $d <br><br>";

echo "pow dikalikan sqrt hasilnya = $hasil <br><br>";

$skr = date("d/m/y");
echo "Sekarang tanggal $skr <br>";
$waktu = date("h:i:s A"); 
echo "Jam menunjukan pukul : $waktu";

?>
